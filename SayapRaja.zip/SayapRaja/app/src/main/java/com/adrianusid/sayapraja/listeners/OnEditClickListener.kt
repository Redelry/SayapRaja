package com.adrianusid.sayapraja.listeners

import com.adrianusid.sayapraja.model.ListJobModel

interface OnEditClickListener {
    fun onEditClick(data: ListJobModel)
}