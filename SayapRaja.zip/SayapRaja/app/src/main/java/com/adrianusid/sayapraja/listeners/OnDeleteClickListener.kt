package com.adrianusid.sayapraja.listeners

import com.adrianusid.sayapraja.model.ListJobModel

interface OnDeleteClickListener {
    fun onDeleteClick(data: ListJobModel)
}