package com.adrianusid.sayapraja.model

data class LoginModel (

    val username: String,
    val password: String
        )